/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: LordH
 *
 * Created on October 11, 2017, 7:05 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    int prg;
    
    cout << "Choose a program to initialize.\n";
    cout << endl << " 1. Minimum Maximum\n";
    cout << "2. Magic Dates\n";
    cout << "3. Areas of Rectangles\n";
    cout << "4. Body Mass Index\n";
    cout << "5. Mass and Weight\n";
    cout << "6. Color Mixer\n";
    cout << "7. Change for a Dollar Game\n";
    cout << "8. Software Sales\n";
    cout << "9. Running the Race\n";
    cout << "10. Savitch Ch.3 Prob.9\n";
    
    cin >> prg;
    
    // program 1
    switch(prg){
        case 1:
    
    int num1,num2;
    
    cout << "Input a number:\n";
    cin >> num1;
    cout << "Input a second number:\n";
    cin >> num2;
    
    if (num1>num2){
        cout << "Number " << num1 << " is greater than Number " << num2 << endl;
    }
    else if (num2>num1){
       cout << "Number " << num2 << " is greater than Number " << num1 << endl; 
    }
    }
    
    // program 2
    switch(prg){
        case 2:
            
    int mon, dy, yr;
    
        cout << "Please input in numeric form. ie., 6/10/60.\n";

        cout << "Input month:\n";
        cin >> mon;

        cout <<"Input day:\n";
        cin >> dy;

        cout << "Input year:\n";
        cin >> yr;

        cout<<"You inputted: " << mon << "/" << dy << "/" << yr << "\n";
        
            if (mon*dy == yr){
                cout << "Date is magic.\n";
            }
            else{ 
                cout << "Date isn't magic.\n";
            }
    }
    
    // program 3
    switch(prg){
        case 3:
            int rect1L,         // rect 1 length
            rect1W,     // rect 1 width
            rect2L,     // rect 2 length
            rect2W;     // rect 2 width
    
    int rect1A,     // rect 1 area
            rect2A; // rect 2 area 
    
    cout << "Enter length of first rectangle:\n";
    cin >> rect1L;
    cout << "Enter width of first rectangle:\n";
    cin >> rect1W;
    cout << "Enter length of second rectangle:\n";
    cin >> rect2L;
    cout << "Enter width of second rectangle:\n";
    cin >> rect2W;
    
    rect1A = rect1L*rect1W;
    rect2A = rect2L*rect2W;
    
    cout << "Area of first rectangle:  " << rect1A << endl;
    cout << "Area of second rectangle: " << rect2A << endl;
    
    }
    
    // program 4
    switch(prg){
        case 4:
            int wt,     // weight in lbs
            ht, // height in inches
            bmi;// body mass index
    
    cout << "Enter your weight in lbs: \n";
    cin >> wt;
    cout << "Enter your height in inches:\n";
    cin >> ht;
    bmi = wt*(703/pow(ht,2));
    
    if (bmi<18.5){
        cout << "Your BMI of " << bmi << " indicates you are underweight.\n";
    }
    else if (bmi<=25){
        cout << "Your BMI of " << bmi << " indicates you are at optimal weight.\n";
    }
    else
        cout << "Your BMi of " << bmi << " indicated you are overweight.";
   
    }
    
    // program 5
    switch(prg){
        case 5:
            
     int mass,   // lbs
        weight; // newtons
    
    
    cout << "Enter the weight in lbs:\n";
    cin >> mass;

    weight= mass*9.8;
    
    cout << "The mass in lbs: " << weight << " Newtons.\n";
    if(weight>1000){
        cout << "The object's mass is too heavy.";
    }
    else
        cout << "Your object's mass is too light.";
    
           
    }
    
    // program 6
    switch(prg){
        case 6:
            string c1,c2;
    
    cout << "Enter two colors: red, blue, yellow\n";
    cin >> c1;
    cin >> c2;
    
    if ((c1 == "blue" && c2 == "red")||(c1== "red" && c2 == "blue")){
        cout << "Purple color!";
    }
    else if ((c1 == "red" && c2 == "yellow")||(c1== "yellow" && c2 == "red")){
        cout << "Orange color!";
    }
    else if ((c1 == "blue" && c2 == "yellow")||(c1== "yellow" && c2 == "blue")){
        cout << "Green color!";
    }
    else{
        cout << "No. Not those colors.";
    }
    }
    
    // program 7
    switch(prg){
        case 7:
            int penA,        // pennies am
            nicA,    // nickels am
            dimA,    // dimes am
            quaA;    // quarters am
    
    int pen,        // pennies 
            nic,    // nickels
            dim,    // dimes 
            qua;    // quarters 
    int tot;
    
     penA=.01;
    nicA=.05;
    dimA=.10;
    quaA=.25;
    
    cout << "Enter the amount of pennies:\n";
    cin >> pen;
    cout << "Enter the amount of nickels:\n";
    cin >> nic;
    cout << "Enter the amount of dimes:\n";
    cin >> dim;
    cout << "Enter the amount of quarters:\n";
    cin >> qua;
    
   tot = (pen*penA)+(nic*nicA)+(dim*dimA)+(qua*quaA);
    
    if (tot==1.00){
        cout << "You entered a dollar. You win.";
    }
    else{
        cout << "You entered more or less than a dollar. You lose.";
    }
    
    
    }
    
    // program 8
    switch(prg){
        case 8:
            int quan,price,total;
    
    
    cout << "Enter the amount of software purchased:\n";
    cin >> quan; 
    price=99;
    total = quan*price;
     
    if (quan<10){
                cout << "You purchased " << quan << " softwares with total of $" << total
                        << " with no discount applied.";
            }
    else if (quan>=10 && quan<=19){
                cout << "You purchased " << quan << " softwares with total of $" << total*(.2)
                        << " with 20% discount applied.";
            }
        else if (quan>=20 && quan<=49){
            cout << "You purchased " << quan << " softwares with total of $" 
                    << total*(.3) << " with 30% discount applied.";
            }
        else if (quan >=50 && quan<=99){
                cout << "You purchased " << quan << " softwares with total of $" 
                        << total*(.4) << " with 40% discount applied.";
        }
        else if (quan >=100){
                cout << "You purchased " << quan << " softwares with total of $" 
                        << total*(.5) << " with 50% discount applied.";
        }
        else{
            cout << "Invalid number purchased.";
        }
    }
    
    // program 9
    switch(prg){
        case 9:
             string run1,run2,run3;  // runner names
    int run1t,run2t,run3t;  // runner times
    
    cout << "Enter runner one: \n";
    cin >> run1;
    cout << "Enter runner's time in seconds:\n";
    cin >> run1t;
    
    cout << "Enter runner two: \n";
    cin >> run2;
    cout << "Enter runner's time in seconds:\n";
    cin >> run2t;
    
    cout << "Enter runner three: \n";
    cin >> run3;
    cout << "Enter runner's time in seconds:\n";
    cin >> run3t;
    
    if(run1t>run2t&&run2t>run3t){
        cout << "Third Place: " << run1 << "\nSecond Place: " << run2 << "\n First Place: " << run3 <<endl;
    }
       else if (run1t>run2t&&run2t<run3t){
            cout << "Third Place: " << run1 << "\nSecond Place: " << run3 << "\nFirst Place: " <<run2 <<endl;
        }
        else if(run2t>run1t&&run1t>run3t){
            cout << "Third Place: " << run2 << "\nSecond Place: " << run1 << "\nFirst Place: " <<run3 <<endl;
        }
        else if (run2t>run1t&&run1t>run3t){
            cout << "Third Place: " << run2 << "\nSecond Place: " << run3 << "\nFirst Place: " <<run1 <<endl;
        }
        else if (run2t>run1t&&run1t>run3t){
            cout << "Third Place: " << run2 << "\nSecond Place: " << run3 << "\nFirst Place: " <<run1 <<endl;
        }
        else if (run3t>run1t&&run1t>run2t){
            cout << "Third Place: " << run3 << "\nSecond Place: " << run1 << "\nFirst Place: " << run2 <<endl;
        }
        else if (run3t>run1t&&run1t<run2t){
            cout << "Third Place: " << run3 << "\nSecond Place: " << run2 << "\nFirst Place: " << run1 <<endl;
        }
    }
    
    // program 10
    switch(prg){
        case 10:
            int fi, fim1, fim2, counter;
    int wtCrud = 5;     // 5 lbs of crud
    int deltDys = 5;    // 5 days between
    
    fim1 = fim2 = 1; // initialize sequence
    counter = 3;    // start with the 3rd term
    
    //1
    cout << "Sequence   Crud Wt     N Days\n";
    cout << setw(8) << fim2 << setw(10) << wtCrud*fim2
            << setw(11) << counter*deltDys << endl;
    counter += 1;
    
    //2
    cout << setw(8) << fim1 << setw(10) << wtCrud*fim1
            << setw(11) << (counter-1)*deltDys << endl;
    counter += 1;
    
    //3
    fi = fim1 + fim2;
    cout << setw(8) << fim1 << setw(10) << wtCrud*fi
            << setw(11) << counter*deltDys << endl;
    counter += 1; 
    }
    return 0;
}

