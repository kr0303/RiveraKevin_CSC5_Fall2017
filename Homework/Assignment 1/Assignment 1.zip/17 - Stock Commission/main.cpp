/* 
 * File:   main.cpp
 * Author: Rivera, Kevin
 * Created on August 31, 2017, 12:35 PM
 * Purpose: Stock purchase
 */

#include <iostream>

using namespace std;


/*
 * **KNOWNS**
 * 750 shares
 * $35/share
 * SB fee 2%
 * 
 * **UNKNOWNS**
 * cost of stock
 * commission paid
 * total amt paid
 */

int main(int argc, char** argv) {
    short nShrs; // number of shares of stock
    float ppShr, fee; // pricer per share in $/share and fee as percent
    // share cost in $, commission paid in $, total paid in $
    float shrCost, comPaid, totPaid;
    
    
    nShrs= 750;
    ppShr= 35;
    fee= 2;
    
    shrCost= nShrs*ppShr;
    comPaid= shrCost*fee/100; // convert percentage to decimal
    totPaid= shrCost+comPaid;
    
    cout << "Number of shares  = " << nShrs << endl;
    cout << "Share price       = $" << ppShr << endl;
    cout << "Commission fee    = " << fee << "%" << endl;
    cout << "Cost of shares    = $" << shrCost << endl;
    cout << "Commission paid   = $" << comPaid << endl;
    cout << "Total amount paid = $" << totPaid;
    
    return 0;
}
