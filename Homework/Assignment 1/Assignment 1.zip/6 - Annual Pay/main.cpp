/* 
 * File: [Template]
 * Author: Rivera, Kevin
 *
 * Created on September 17, 2017, 5:13 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float pAmt,
            pP,
            aP;
    
    pAmt=2200;
    pP=26;
    aP=pAmt*pP;
    
    cout << "Pay Amount: $" << pAmt << endl;
    cout << "Pay Period: $" << pP << endl;
    cout << "Annual Pay: $" << aP << endl;
    return 0;
}

