/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
 
//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float cust;     // total customers surveyed
    float drink;    // surveyed drinkers
    float cit;      // drinkers citrus 
    float oth;      // drinkers other
    
    //Input or initialize values Here
    cust = 16500;
    drink = 2475;
    cit = drink*.58;    // 58% prefer citrus
    oth = drink - cit;  // other drink
    
    //Process/Calculations Here
    
    //Output Located Here
    cout << "Total Customers Surveyed           : " << cust << endl;
    cout << "Total Amt. of Customers Who Drink  : " << drink << endl;
    cout << endl;
    
    cout << "Total Drinkers Who Prefer Citrus   : " << cit << endl;
    cout << "Total Drinkers Who Prefer Other    : " << oth << endl;
    //Exit
    return 0;
}

