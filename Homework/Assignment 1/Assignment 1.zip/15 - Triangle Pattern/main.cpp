/* 
 * File:   main.cpp
 * Author: Rivera, Kevin
 * Created on August 31, 2017, 12:10 PM
 * Purpose: Problem 15
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
 
    cout << "   *" << endl;
    cout << "  ***" << endl;
    cout << " *****" << endl;
    cout << "*******" << endl;
    
    cout <<endl;
    
    cout << "   *\n";
    cout << "  ***\n";
    cout << " *****\n";
    cout << "*******\n";
    

        
    return 0;
}
