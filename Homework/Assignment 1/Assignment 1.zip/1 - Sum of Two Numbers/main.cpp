/* 
 * File: [Template]
 * Author: Rivera, Kevin
 *
 * Created on September 17, 2017, 5:13 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float sum1;
    float sum2;
    float ttl;
    
    sum1=50;
    sum2=100;
    ttl=sum1+sum2;
    
    cout << "One variable is " << sum1<< ". The other variable is " << sum2 << ".\n";
    cout << "The sum of both variables totals to " << ttl << endl;
    return 0;
}

