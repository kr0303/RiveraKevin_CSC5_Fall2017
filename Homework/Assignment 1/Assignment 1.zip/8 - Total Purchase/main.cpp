/* 
 * File: [Template]
 * Author: Rivera, Kevin
 *
 * Created on September 17, 2017, 5:13 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    return 0;
}

