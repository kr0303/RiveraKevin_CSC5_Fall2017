/* 
 * File: [Template]
 * Author: Rivera, Kevin
 *
 * Created on September 17, 2017, 5:13 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float mC,       //meal charge
            tax,    
            tip,    //total tip after tax 20%
            sTtl,
            ttl;
    
    mC=88.67;
    tax=.0675*mC;
    sTtl=mC+tax;
    tip=sTtl*.2;
    ttl = sTtl+tip;
    
    cout << "Meal Cost: $" << mC << endl;
    cout << "Tax:       $" << tax << endl;
    cout << "Subtotal:  $" << sTtl << endl;
    cout << "Tip:       $" << tip << endl;
    cout << "Total:     $" << ttl << endl;
    
    return 0;
}

