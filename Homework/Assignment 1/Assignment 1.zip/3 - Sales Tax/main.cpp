/* 
 * File: [Template]
 * Author: Rivera, Kevin
 *
 * Created on September 17, 2017, 5:13 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float purc, // purchase amount
            sst, // state sales tax
            cst, // county sales tax
            tst; // total sales tax
    
    purc=95;
    sst=.04*95; // 4%
    cst=.02*95; //2%
    tst=sst+cst;
    
    cout << "Purchase Total: $95\n";
    cout << "State Sales Tax: $" << sst << endl;
    cout << "County Sales Tax: $" << cst << endl;
    cout << "Total Sales Tax: $" << tst << endl;
    
    
    
    
    return 0;
}

