
#include <iostream>    
#include <iomanip>     
using namespace std;   

int main(int argc, char** argv) {
    //Declare Variables
    const float YENPDOL=98.93f; // Yen per dollar
    const float EURPDOL=.74f;  // Euro per dollar
    float dollar;
  
    
    cout<<"Enter US Dollar Amount: "<<endl;
    cin>>dollar;
    
  
    float convYen=static_cast<float>(dollar)*YENPDOL;
    float convEur=static_cast<float>(dollar)*EURPDOL;
    

    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<" "<<endl;
    cout<<"Conversion Results from "<<dollar<<" dollars."<<endl;
    cout<<"Dollar to Yen: "<<convYen<<endl;
    cout<<"Dollar to Euro: "<<convEur<<endl;
    
    

    return 0;
}