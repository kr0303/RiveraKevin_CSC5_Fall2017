
#include <iostream>     //Input/Output Stream Library
#include <iomanip>      //Fixed Precision
using namespace std;    //Standard Name-space under which System Libraries reside




const unsigned char PCTCON=100; //Percent Conversion



int main(int argc, char** argv) {

    unsigned int male, female;
       
   
    float tS; //total students
    float pM;   //male %
    float pF;   //female %
    
  
    cout<<"This program displays the percentage of males and females registered"
            <<"in a class"<<endl;
    cout<<"Enter the number of males in your class."<<endl;
    cin>>male;
    cout<<"Enter the number of females in your class"<<endl;
    cin>>female;
    
    tS=male+female;
    pM=male/tS*PCTCON;
    pF=female/tS*PCTCON;
    

    cout<<fixed<<setprecision(0)<<showpoint;
    cout<<" "<<endl;
    cout<<" "<<endl;
    cout<<"The total percentage of males in your class is "<<pM<<"%."<<endl;
    cout<<"The total percentage of females in your class is "<<pF<<"%."<<endl;
    
  
    

    return 0;
}