/* 
 * File:   main.cpp
 * Author: LordH
 *
 * Created on September 26, 2017, 9:35 PM
 */

#include <iostream>
#include <string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    string name,
            age,
            city,
            college,
            profession,
            animal,
            petname;
    
    cout << "Enter your name:\n";
    cin >> name;
    
    cout << "Enter your age:\n";
    cin >> age;
    
    cout << "Enter your city:\n";
    cin >> city;
    
    cout << "Enter your college:\n";
    cin >> college;
    
    cout << "Enter your profession:\n";
    cin >> profession;
    
    cout << "Enter a type of animal:\n";
    cin >> animal;
    
    cout << "Enter a pet name:\n";
    cin >> petname;
    
    cout << "There was once a person named " << name << " who lived in " 
            << city << ". At the age of " << age << ", " << name << " went to"
            " college at " << college << ". " << name << " graduated and went"
            " to work as a " << profession << ". Then, " << name << " adopted"
            " a(n) " << animal << " named " << petname << ". They both lived"
            " happily ever after!";
           
    return 0;
}

