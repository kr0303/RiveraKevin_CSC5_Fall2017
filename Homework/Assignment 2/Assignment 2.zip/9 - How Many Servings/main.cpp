
#include <iostream>    
using namespace std;    

int main(int argc, char** argv) {
   
    unsigned short cCookie; //cal/cookie
    unsigned short totCal;  //total calories
    unsigned short cookie;  //c ookies ate
    

    cCookie=100;
    
  
    cout<<"This program calculates the amount of calories consumed by the total"
            <<" amount of cookies eaten."<<endl;
    cout<<"How many total cookies did you eat?"<<endl;
    cin>>cookie;
    
    totCal=cookie*cCookie; 
    
 
    cout<<"The amount of calories you consumed is "<<totCal<<" calories."<<endl;
    
    return 0;
}