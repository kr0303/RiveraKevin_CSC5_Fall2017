#include <iostream>
#include <cmath>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int t1,
            t2,
            t3,
            t4,
            t5;
    
    
    
    cout<< "Enter Test 1 Score: \n";
    cin>>t1;
    cout<< "Enter Test 2 Score: \n";
    cin>>t2;
    cout<< "Enter Test 3 Score: \n";
    cin>>t3;
    cout<< "Enter Test 4 Score: \n";
    cin>>t4;
    cout<< "Enter Test 5 Score: \n";
    cin>>t5;
    int avg = (t1+t2+t3+t4+t5)/5;
    cout<<endl<<"Average of Scores: " << avg<<endl;
    return 0;
}

