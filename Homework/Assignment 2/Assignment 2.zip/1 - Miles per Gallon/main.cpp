#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
   
    int hold,     //car hold
            tank;   //drive on full tank
    
    int mpg = hold/tank; // miles per gallon
    
    cout << "Enter the amount of tank hold in gallons.\n";
    cin >> hold;
    cout << "Enter the amount of miles on full tank.\n" << endl;
    cin >> tank;
    
    cout << endl << "Car can hold:  " << hold << " gallons.\n";
    cout << "Car can drive: " << tank << " miles.\n";
    cout << "Estimated MPG: " << mpg << endl;
    return 0;
}

