/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on September 21, 2017, 11:27 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */

    float const cC=.35;     // concetration in can
    
int main(int argc, char** argv) {

    float hWt=90718.5,              //human weight in grams
            mM=35,                  //mass of mouse in grams
            mK=5,                   //mass of sugar to kill mouse
            mC=350,                 //mass of coke can
            rat=0.1428571429;       //ratio mass to sugar mass
    
    float mThrsh,           //mouse can to kill
            sugKH,          // sugar threshold kill human
            canK;           // cans to kill human
    
    mThrsh=mK/cC;
    sugKH=hWt*rat;
    canK=sugKH/cC;
    
    cout << "Human Weight:              " << hWt << " grams\n";
    cout << "Mouse Mass:                    " << mM << " grams\n";
    cout << "Sugar to Kill Mouse:           " << mK << " grams\n";
    cout << "Mass in Coke:                  " << mC << " grams\n";
    cout << "Concetration of Sugar:         " << cC << " grams\n" << endl;
    
    cout << "Cans to Reach Mouse Threshold: " << mThrsh << " cans\n";
    cout << "Sugar Threshold to Kill Human: " << sugKH << " grams\n";
    cout << "Cans of Coke to Kill Human:    " << canK << " grams\n.";
    
    
          
    
    
    return 0;
}

