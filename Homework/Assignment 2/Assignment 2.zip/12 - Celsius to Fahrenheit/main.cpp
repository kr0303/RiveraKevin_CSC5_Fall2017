/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: LordH
 *
 * Created on September 26, 2017, 8:12 PM
 */

#include <iostream>
#include <cmath>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    int c;
    int f;
    
    cout << "Enter temperature in Celsius:\n";
    cin >> c;
      
    f = (9/5)*c+32;
    cout << c <<" Celsius is " << f << " in Fahrenheit.\n";
  
    return 0;
}

