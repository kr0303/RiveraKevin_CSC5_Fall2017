/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on September 19, 2017, 11:26 AM
 */

#include <iostream>
#include <cmath>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float   i=.12,     // i per year
            num=36,     // number of months
            loan=10000,
            mp=loan/num,
            ttlP= mp*num, // total paid
            intP=ttlP-loan; // interest
    
    /*
     monthly payment: 278 < x < 389
     */
    
    cout<<"Number of Months:    "<<num<<endl;
    cout<<"% per Year:          "<<i*100<<"%\n";
    cout<<"Loan Amount:         $"<<loan<<endl<<endl;
    
    cout<<"Monthly Payments:    $"<<mp<<endl;
    cout<<"Total Paid:          $"<<ttlP<<endl;
    cout<<"Interest Paid:       $"<<intP<<endl;
    
    return 0;
}

