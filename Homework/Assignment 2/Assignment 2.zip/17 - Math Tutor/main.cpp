/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on September 19, 2017, 12:33 PM
 */

#include <iostream>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float op1,
            op2;
    
    op1 = rand()%900+100; // 100-999
    op2 = rand()%900+100; // 100-999
    
    return 0;
}

