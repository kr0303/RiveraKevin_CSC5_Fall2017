

#include <iostream>
#include <cmath>
#include <fstream>
#include <cstring>
using namespace std;    

int main(int argc, char** argv) {
    int choice;

    do{

        cout<<"What program would you like to run?\n";
        cout<<"1. Population Growth\n";
        cout<<"2. Triangular Patterns\n";
        cout<<"3. Web Page\n";
        cout<<"4. How Many Slugs?\n";
        cout<<"5. Vending Machine\n";
        cout<<"6. Calories Burned\n";
        cout<<"7. Sum of Numbers\n";
        cout<<"8. Ocean Levels\n";
        cout<<"9. Square Pattern\n";
        cin>>choice;

        switch(choice){
            case 1:{
                cout<<"You are now running Population Growth\n";
                
            float pop,incPop,popPow;
    int nYears;

    cout<<"Calculate the increase in population over time\n";
    cout<<"Input the population, percentage yearly increase and \n";
    cout<<"The number of years\n";
    cin>>pop>>incPop>>nYears;

    float temp=(1+incPop/100.0f);
    popPow=pop*pow(temp,nYears); 
    for(int year=1;year<=nYears;year++){
        pop*=temp;
    }

    cout<<"The resulting population in "<<nYears<<" years = "
            <<pop<<" people using a loop\n";
    cout<<"  Same result population in "<<nYears<<" years = "
            <<popPow<<" people using the pow()\n\n";    
                break;
            }
            
            case 2:{
                cout<<"You are now running Triangular Patterns\n";
                
        for(int cnt1=1,cnt2=19,cnt3=10;cnt1<=10;cnt1++,cnt2--,cnt3--){
        //Display First Triangle
        for(int t1=1;t1<=cnt1;t1++)cout<<"*";
        //Display Middle Spaces
        for(int t1=1;t1<=cnt2;t1++)cout<<" ";
        //Display Second Triangle
        for(int t1=1;t1<=cnt3;t1++)cout<<"*";
        cout<<endl;
    }
                break;
            }
            
            case 3:{
    cout<<"You are now running Web Page\n";
    
    string fName,usrName,usrBio;
    ofstream out;
    
    //Initialize Variables
    fName="webpage.html";
    out.open(fName.c_str());
    
    //Input Data/Variables
    cout<<"Generate Code for a Bio Webpage\n";
    cout<<"Input Name\n";
    cin >> usrName;
    cout<<"Input Bio\n";
    getline(cin,usrBio);
    
    //Generate the Web page
    cout<<"<html>\n";
    cout<<"  <head>\n";
    cout<<"    <title>Gaddis 9thEd Chap5 Prob26 Web Page Generator</title>\n";
    cout<<"  </head>\n";
    cout<<"  <body>\n";
    cout<<"    <center>\n";
    cout<<"        <h1>"<<usrName<<"</h1>\n";
    cout<<"        <hr />\n";
    cout<<"            "<<usrBio<<endl;
    cout<<"        <hr />\n";
    cout<<"    </center>\n";
    cout<<"  </body>\n";
    cout<<"</html>\n";
    
    //Generate the Web page
    out<<"<html>\n";
    out<<"  <head>\n";
    out<<"    <title>Gaddis 9thEd Chap5 Prob26 Web Page Generator</title>\n";
    out<<"  </head>\n";
    out<<"  <body>\n";
    out<<"    <center>\n";
    out<<"        <h1>"<<usrName<<"</h1>\n";
    out<<"        <hr />\n";
    out<<"            "<<usrBio<<endl;
    out<<"        <hr />\n";
    out<<"    </center>\n";
    out<<"  </body>\n";
    out<<"</html>\n";
    
    //Close the file
    out.close();
                break;
            }
            
            case 4:{
                cout<<"You are now running How Many Slugs?\n";
                
const float GRAVITY = 6.673e-8f; // universal gravitational conversion
const float CNVCMFT = 1/30.48; // 30.48 cm/ft
const float CNVMFT = 5280.0f; // 5280 ft/mile
const float CNVGKG = 1000.0f; // 1000.0 grams to 1 kilogram
const float REARTH = 3959.0f; // radius of the earth
const float MEARTH = 5.972e24f; // mass of the earth

float mMass,    // my mass
            mWt,    // my weight
            aWt;    // actual weight
    
    mMass=6.0f;
    
    cout << "This program converts your weight in lbs to "
            << "your mass in slugs.\n"
            << "Input your actual weight in lbs.\n\n";
    cin >> aWt;
    
    float delta,
            tol=.01f,
            kG=tol;
    do{
    mWt = GRAVITY*CNVCMFT*CNVCMFT*CNVCMFT*MEARTH*CNVGKG*mMass/
            (REARTH*REARTH*CNVMFT*CNVMFT);
        delta = aWt-mWt;
        mMass += kG*delta;
    } while(abs(delta)>=tol);
    
    cout << "Your weight = " << mWt << " lbs.\n";
    cout << "Your mass   = " << mMass << " slugs.\n";

                break;
            }
            
            case 5:{
                cout<<"You are running Vending Machine\n";
                
const char  DOLLAR =100;      // all of them are counted in pennies
const char  QUARTER= 25;  
const char  DIME   = 10;
const char  NICKEL =  5;     
const float HLFPNY =0.005f;   //Half penny round up
const char  CNVPNY =100;      //Conversion to a penny

float price,tndrd;
    unsigned short change;
    unsigned char nDlrs,nQtrs,nDimes,nNckls;
    
    //Initialize Variables
    
    //Input Data/Variables
    do{
        cout<<"The Vending Machine Problem calculates the change\n";
        cout<<"Input the Price of the Product and the Amount Tendered\n";
        cin>>price>>tndrd;
    }while(price>tndrd);
    
    //Calculate the change
    change=(tndrd-price+HLFPNY)*CNVPNY;//Accounts for float inaccuracy
    nDlrs=(change-change%DOLLAR)/DOLLAR;
    change-=(nDlrs*DOLLAR);
    nQtrs=(change-change%QUARTER)/QUARTER;
    change-=(nQtrs*QUARTER);
    nDimes=(change-change%DIME)/DIME;
    change-=(nDimes*DIME);
    nNckls=(change-change%NICKEL)/NICKEL;
    change-=(nNckls*NICKEL);
    change=nDlrs*DOLLAR+nQtrs*QUARTER+nDimes*DIME+nNckls*NICKEL;
    
    
    //Display/Output all pertinent variables
    cout<<"The change in Pennies  = "<<change<<endl;
    cout<<"The number of Dollars  = "<<static_cast<int>(nDlrs)<<endl;
    cout<<"The number of Quarters = "<<static_cast<int>(nQtrs)<<endl;
    cout<<"The number of Dimes    = "<<static_cast<int>(nDimes)<<endl;
    cout<<"The number of Nickels  = "<<static_cast<int>(nNckls)<<endl;
                break;
            }
            case 6:{
                cout<<"You are now running Calories Burning\n";

    int calB;       // calories burned
    float calBM = 3.6; // calories burned per minute
    
    for(int i=10; i<=30; i+=5){
        calB=i*calBM;
        cout << "Within " << i << " minutes, you have burned " << calB <<
                " calories.\n";
    }
                break;
            }
            
            case 7:{
                cout<<"You are running Sum of Numbers\n";
                
    int num = 0, sum = 0;
    
    cout << " Enter the amount of number you'd like to sum up.\n";
    cin >> num;
    
    while (num < 0)
    {
        cout << " Please enter a number 1-50\n";
        cin >> num;
        
    }
    
    for (int c = 1; c <= num; c++)
    {
        sum += c;
    }
    
    cout << "The sum is " << sum << "."<<endl;
                break;
            }
            
            case 8:{
                cout<<"You are now running Ocean Levels\n";
     float oLvl = 1.5;      //Ocean level rise per year (mm)
    short year = 1;         //Base year 
    
    cout << " This program was developed to display the rise of the ocean level" 
     " (mm) per year for the next 25 years.\n";
    cout << " Year                       Ocean level rise (mm)\n";
    cout << " ------------------------------------------------\n";
    
    for (; year <= 25; year++)
    cout<< year <<"                             "<< year*oLvl <<endl;
                break;
            }
            
            case 9:{
    int sqr ;
    
    cout << "Input a number from 1 to 15.\n";
    cin >> sqr;
    
    while ( sqr < 1 )
    {
        cout << "Input a correct number from that range!!!\n";
        cin >> sqr;
    }
    while ( sqr > 15 )
    {
        cout << "Input a correct number from that range!!!\n";
        cin >> sqr;
    }
    
    for ( int w = 1; w <= sqr; w++)
    {
        for ( int l =1; l <= sqr; l ++)
        { 
            cout << "x";       
        }
        cout << endl;
    }
                break;
            }
            default:{
                cout<<"Run another program because it has no exit!\n";
            }
        }
    }while(choice>0&&choice<10);

    return 0;
}